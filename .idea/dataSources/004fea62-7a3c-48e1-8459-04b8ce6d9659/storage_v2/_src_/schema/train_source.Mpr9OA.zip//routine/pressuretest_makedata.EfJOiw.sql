CREATE PROCEDURE PressureTest_MakeData(IN PressureTest_MakeData BIGINT)
  BEGIN
#Routine body goes here...
	
DECLARE i INT DEFAULT 1;

while (i <= 1000000) do

insert into orders2(price, depno) values( rand()*100-50, rand()*10);

set i = i + 1;

end while;

commit;

END;

