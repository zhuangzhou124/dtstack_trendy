CREATE VIEW v_liudang_test AS
  SELECT `chen_t`.`t_e_paper_answer`.`publishid`                                                                  AS `publishid`,
         `chen_t`.`t_e_paper_answer`.`answeruserid`                                                               AS `answeruserid`,
         `chen_t`.`t_e_paper_answer`.`answerusername`                                                             AS `answerusername`,
         `chen_t`.`t_e_paper_answer`.`score`                                                                      AS `score`,
         `chen_t`.`t_e_paper_answer`.`startanwsertime`                                                            AS `startanwsertime`,
         `chen_t`.`t_e_paper_answer`.`submittime`                                                                 AS `submittime`,
         str_to_date(`chen_t`.`t_e_paper_answer`.`startanwsertime`,
                     '%d/%m/%Y %H:%i:%s')                                                                         AS `formatanswer_date`,
         date_format(str_to_date(`chen_t`.`t_e_paper_answer`.`startanwsertime`, '%d/%m/%Y %H:%i:%s'),
                     '%Y-%m-%d')                                                                                  AS `startanwser_date`,
         extract(HOUR FROM str_to_date(`chen_t`.`t_e_paper_answer`.`startanwsertime`,
                                       '%d/%m/%Y %H:%i:%s'))                                                      AS `startanwser_hour`
  FROM `chen_t`.`t_e_paper_answer`;

