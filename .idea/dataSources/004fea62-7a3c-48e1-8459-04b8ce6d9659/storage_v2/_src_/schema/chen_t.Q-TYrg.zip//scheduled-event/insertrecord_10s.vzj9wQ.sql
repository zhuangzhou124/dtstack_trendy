CREATE DEFINER = dtstack_test@`%` EVENT insertRecord_10s
  ON SCHEDULE
    EVERY '10' SECOND
      STARTS '2019-03-25 20:53:49'
  ON COMPLETION PRESERVE
  ENABLE
DO
  insert into sales VALUES (default,"u001","张三","p001",10.00, 1, FORMAT(RAND(),2), REPLACE(unix_timestamp(current_timestamp(3)),'.',''));

